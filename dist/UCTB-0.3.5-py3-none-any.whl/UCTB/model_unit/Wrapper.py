import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.optim as optim
import logging
from torchmetrics import Accuracy

class BaseModel(pl.LightningModule):
    def __init__(self, model: nn.Module, learning_rate: float = 0.001, freeze_list=None):
        super().__init__()
        self.model = model
        self.learning_rate = learning_rate
        self.loss_fn = nn.CrossEntropyLoss()
        self.accuracy = Accuracy()

        self.freeze_list = freeze_list or []
        if freeze_list:
            set_trainable_parameters(self.model, self.freeze_list)
    
    def forward(self, *args):
        # the model should be a callable object
        return self.model(args) 
    
    def training_step(self, batch, batch_idx):
        x, y = batch
        logits = self(x)
        loss = self.loss_fn(logits, y)
        acc = self.accuracy(logits, y)
        self.log('train_loss', loss, prog_bar=True)
        self.log('train_acc', acc, prog_bar=True)
        return loss
    
    def validation_step(self, batch, batch_idx):
        x, y = batch
        logits = self(x)
        loss = self.loss_fn(logits, y)
        acc = self.accuracy(logits, y)
        self.log('val_loss', loss, prog_bar=True)
        self.log('val_acc', acc, prog_bar=True)
    
    def test_step(self, batch, batch_idx):
        x, y = batch
        logits = self(x)
        loss = self.loss_fn(logits, y)
        acc = self.accuracy(logits, y)
        self.log('test_loss', loss, prog_bar=True)
        self.log('test_acc', acc, prog_bar=True)
    
    def configure_optimizers(self):
        optimizer = optim.Adam(self.parameters(), lr=self.learning_rate)
        return optimizer
    
    
def set_trainable_parameters(model, freeze_list):
    """
    Function to freeze certain parameters and allow others to be trainable.

    Args:
    - model: The PyTorch model or nn.Module that contains the parameters.
    - freeze_list: A list of strings representing the names of the parameters (layers) to be frozen.

    Returns:
    - None
    """
    for name, param in model.named_parameters():
        # Freeze parameters if they are in the freeze_list
        if any(layer_name in name for layer_name in freeze_list):
            param.requires_grad = False
            logging.info(f'Frozen layer: {name}')
        else:
            param.requires_grad = True  # Ensure other parameters are trainable
            logging.info(f'Trainable layer: {name}')


if __name__ == "__main__":
    # Test the BaseModel class
    model = nn.Linear(10, 2)
    model = BaseModel(model)
    # Assume you have a PyTorch model called `model`
    freeze_list = ['layer1', 'layer2', 'conv1.weight']  # List of layer names or parameters you want to freeze
    set_trainable_parameters(model, freeze_list)