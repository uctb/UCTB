import os
import torch
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping
from torch.utils.data import DataLoader, Dataset
import logging
from torch import nn
from torch.optim import Adam
from torch.utils.tensorboard import SummaryWriter
import numpy as np

class BaseDataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return {'data': torch.tensor(self.data[idx], dtype=torch.float32),
                'label': torch.tensor(self.labels[idx], dtype=torch.float32)}


class BaseModel(pl.LightningModule):
    def __init__(self, model: nn.Module, lr: float = 1e-3, loss_fn=nn.MSELoss(), freeze_list=None):
        super(BaseModel, self).__init__()
        self.model = model
        self.lr = lr
        self.loss_fn = loss_fn
        self.writer = SummaryWriter()

        self.freeze_list = freeze_list or []
        if freeze_list:
            set_trainable_parameters(self.model, self.freeze_list)
    

    def forward(self, x):
        return self.model(x)

    def training_step(self, batch, batch_idx):
        x, y = batch['data'], batch['label']
        y_hat = self(x)
        loss = self.loss_fn(y_hat, y)
        self.log('train_loss', loss)
        return loss

    def validation_step(self, batch, batch_idx):
        x, y = batch['data'], batch['label']
        y_hat = self(x)
        val_loss = self.loss_fn(y_hat, y)
        self.log('val_loss', val_loss)
        return val_loss

    def configure_optimizers(self):
        return Adam(self.parameters(), lr=self.lr)

    def save_model(self, checkpoint_path):
        """Method to save model"""
        torch.save(self.state_dict(), checkpoint_path)
        logging.info(f"Model saved to {checkpoint_path}")

    def load_model(self, checkpoint_path):
        """Method to load model"""
        if os.path.exists(checkpoint_path):
            self.load_state_dict(torch.load(checkpoint_path))
            logging.info(f"Model loaded from {checkpoint_path}")
        else:
            raise FileNotFoundError(f"{checkpoint_path} does not exist")

def set_trainable_parameters(model, freeze_list):
    """
    Function to freeze certain parameters and allow others to be trainable.

    Args:
    - model: The PyTorch model or nn.Module that contains the parameters.
    - freeze_list: A list of strings representing the names of the parameters (layers) to be frozen.

    Returns:
    - None
    """
    for name, param in model.named_parameters():
        # Freeze parameters if they are in the freeze_list
        if any(layer_name in name for layer_name in freeze_list):
            param.requires_grad = False
            logging.info(f'Frozen layer: {name}')
        else:
            param.requires_grad = True  # Ensure other parameters are trainable
            logging.info(f'Trainable layer: {name}')

# Trainer Setup
def train_model(model, train_dataset, val_dataset, batch_size=32, max_epochs=100, freeze_list=None,
                checkpoint_dir='checkpoints/', early_stop_patience=5, resume_from_checkpoint=None):
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size)
    
    # Freeze layers if specified
    if freeze_list:
        freeze_layers(model, freeze_list)
    
    # Checkpoint callback to save the best model
    checkpoint_callback = ModelCheckpoint(
        dirpath=checkpoint_dir,
        filename='best-checkpoint',
        save_top_k=1,
        verbose=True,
        monitor='val_loss',
        mode='min'
    )

    # Early stopping callback
    early_stop_callback = EarlyStopping(
        monitor='val_loss',
        patience=early_stop_patience,
        verbose=True,
        mode='min'
    )

    # Trainer
    trainer = pl.Trainer(
        max_epochs=max_epochs,
        gpus=1 if torch.cuda.is_available() else 0,
        callbacks=[checkpoint_callback, early_stop_callback],
        resume_from_checkpoint=resume_from_checkpoint
    )

    # Training
    trainer.fit(model, train_loader, val_loader)



if __name__ == "__main__":
    # Dummy data
    data = np.random.rand(1000, 10)
    labels = np.random.rand(1000, 1)

    # Split into train and validation
    train_data = data[:800]
    train_labels = labels[:800]
    val_data = data[800:]
    val_labels = labels[800:]

    # Create datasets
    train_dataset = BaseDataset(train_data, train_labels)
    val_dataset = BaseDataset(val_data, val_labels)

    # Instantiate the model
    model = BaseModel(input_size=10, output_size=1)

    # Train the model with checkpointing and early stopping
    train_model(model, train_dataset, val_dataset, batch_size=32, max_epochs=50, 
                freeze_list=['model.0'],  # Freeze the first layer
                checkpoint_dir='checkpoints/', 
                early_stop_patience=5)
