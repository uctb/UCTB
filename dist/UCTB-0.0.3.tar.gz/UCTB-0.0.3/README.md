# UCTB

## Project HomePage

[HomePage](https://di-chai.github.io/UCTB/index.html)

## Environment

python 3.6

## Data

Currently Bike data of NYC, Chicago and DC are stored in /Data/ dir. 

Decompressing the data : 

```
cd Data
python compress.py -x
```

