from .multi_threads import multiple_process
from .encode_onehot import one_hot